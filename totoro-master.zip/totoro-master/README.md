# tfdata
Deep Learning with TensorFlow

data 

    ------ A label file that convert label name to numeric id. ---------------------
    
    object-detection.pbtxt

images

    ------ A folder contains two sub-folder of train and test images. Both .jpg and .xml file are stored. ----------

    test

    train
    
generated_tfrecord.py

    ------ A file that creates train data and test data. ----------------------------
    
    convert .xml file to .csv file# totoro
